# HTML version — Pengenalan Sistem Ejaan Jawi

This is a GitHub Pages-ready HTML slide viewer for the supplied 177-page PDF.

## Publish on GitHub
1. Create or open a GitHub repository.
2. Upload `index.html` and the entire `pages` folder (keep the folder name `pages`).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`, then save.
6. Open the GitHub Pages URL shown in the Pages settings.

The viewer preserves the original slide appearance, including Jawi text, by displaying each PDF page as an image. It includes previous/next navigation, direct page entry, arrow-key navigation, and fullscreen viewing.
